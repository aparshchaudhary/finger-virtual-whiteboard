# Gesture Based Virtual Whiteboard

A browser-based virtual whiteboard controlled using hand gestures.

## Features

- Index finger drawing
- Index + middle finger eraser
- Open palm held for 2 seconds to clear the canvas
- Multiple colors
- Adjustable brush size
- Undo
- Save drawing as PNG
- Real-time hand tracking
- Webcam interaction

## Technologies

- HTML
- CSS
- JavaScript
- MediaPipe Hands
- Canvas API
- Vercel

## Run

Open `index.html` using a local server or deploy the project to Vercel.

Allow camera permission and click **Start Camera**.

## Gestures

- Index finger only: Draw
- Index + middle finger: Erase
- Open palm for 2 seconds: Clear
- C: Clear
- U: Undo
- ESC: Reload
