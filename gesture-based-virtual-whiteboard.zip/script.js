const video = document.getElementById("video");
const canvas = document.getElementById("canvas");
const overlay = document.getElementById("overlay");

const ctx = canvas.getContext("2d");
const overlayCtx = overlay.getContext("2d");

const startCameraBtn = document.getElementById("startCamera");
const clearBtn = document.getElementById("clearBtn");
const undoBtn = document.getElementById("undoBtn");
const saveBtn = document.getElementById("saveBtn");

const modeText = document.getElementById("mode");
const cameraStatus = document.getElementById("cameraStatus");
const brushSize = document.getElementById("brushSize");

const VIDEO_WIDTH = 1280;
const VIDEO_HEIGHT = 720;

canvas.width = VIDEO_WIDTH;
canvas.height = VIDEO_HEIGHT;
overlay.width = VIDEO_WIDTH;
overlay.height = VIDEO_HEIGHT;

let currentColor = "#ffffff";
let previousPoint = null;
let history = [];
let clearStart = null;
let camera = null;

function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}

function saveHistory() {
    if (history.length >= 20) history.shift();
    history.push(ctx.getImageData(0, 0, canvas.width, canvas.height));
}

function undo() {
    if (history.length === 0) return;
    ctx.putImageData(history.pop(), 0, 0);
}

function drawLine(x1, y1, x2, y2) {
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.strokeStyle = currentColor;
    ctx.lineWidth = Number(brushSize.value);
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.stroke();
}

function erase(x, y) {
    ctx.save();
    ctx.globalCompositeOperation = "destination-out";
    ctx.beginPath();
    ctx.arc(x, y, 35, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
}

function isFingerUp(landmarks, tip, pip) {
    return landmarks[tip].y < landmarks[pip].y;
}

function processHands(results) {
    overlayCtx.clearRect(0, 0, overlay.width, overlay.height);

    if (!results.multiHandLandmarks?.length) {
        modeText.textContent = "Mode: Idle";
        previousPoint = null;
        clearStart = null;
        return;
    }

    const landmarks = results.multiHandLandmarks[0];

    drawConnectors(overlayCtx, landmarks, HAND_CONNECTIONS, {
        color: "#00ff88",
        lineWidth: 2
    });

    drawLandmarks(overlayCtx, landmarks, {
        color: "#ffffff",
        lineWidth: 1,
        radius: 3
    });

    const indexUp = isFingerUp(landmarks, 8, 6);
    const middleUp = isFingerUp(landmarks, 12, 10);
    const ringUp = isFingerUp(landmarks, 16, 14);
    const pinkyUp = isFingerUp(landmarks, 20, 18);

    const index = landmarks[8];
    const middle = landmarks[12];

    const x = (1 - index.x) * canvas.width;
    const y = index.y * canvas.height;

    const middleX = (1 - middle.x) * canvas.width;
    const middleY = middle.y * canvas.height;

    const openPalm = indexUp && middleUp && ringUp && pinkyUp;

    if (openPalm) {
        modeText.textContent = "Mode: Hold Palm to Clear";
        previousPoint = null;

        if (clearStart === null) clearStart = Date.now();

        const elapsed = (Date.now() - clearStart) / 1000;

        if (elapsed >= 2) {
            saveHistory();
            clearCanvas();
            clearStart = null;
        }

        return;
    }

    clearStart = null;

    if (indexUp && middleUp) {
        modeText.textContent = "Mode: Eraser";
        erase(middleX, middleY);
        previousPoint = null;
        return;
    }

    if (indexUp && !middleUp) {
        modeText.textContent = "Mode: Drawing";

        if (previousPoint === null) {
            saveHistory();
            previousPoint = { x, y };
            return;
        }

        drawLine(previousPoint.x, previousPoint.y, x, y);
        previousPoint = { x, y };
        return;
    }

    modeText.textContent = "Mode: Idle";
    previousPoint = null;
}

const hands = new Hands({
    locateFile: file =>
        `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
});

hands.setOptions({
    maxNumHands: 1,
    modelComplexity: 1,
    minDetectionConfidence: 0.7,
    minTrackingConfidence: 0.7
});

hands.onResults(processHands);

startCameraBtn.addEventListener("click", () => {
    if (camera) return;

    camera = new Camera(video, {
        onFrame: async () => {
            await hands.send({ image: video });
        },
        width: VIDEO_WIDTH,
        height: VIDEO_HEIGHT
    });

    camera.start();

    cameraStatus.textContent = "Camera: On";
    startCameraBtn.textContent = "Camera Running";
});

clearBtn.addEventListener("click", () => {
    saveHistory();
    clearCanvas();
});

undoBtn.addEventListener("click", undo);

saveBtn.addEventListener("click", () => {
    const link = document.createElement("a");
    link.download = "virtual-whiteboard.png";
    link.href = canvas.toDataURL("image/png");
    link.click();
});

document.querySelectorAll(".color").forEach(button => {
    button.addEventListener("click", () => {
        currentColor = button.dataset.color;
    });
});

document.addEventListener("keydown", event => {
    if (event.key === "Escape") location.reload();
    if (event.key.toLowerCase() === "c") {
        saveHistory();
        clearCanvas();
    }
    if (event.key.toLowerCase() === "u") undo();
});
